<?php
	$con=mysqli_connect("localhost","kiccpk_farooq","farooq0324","kiccpk_data");
?>